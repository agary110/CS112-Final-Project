Compile: javac *.java

Run: java Game

Use: Use the ‘j’ key to move the marble left. Use the ‘l’ key to move the marble right. Use the ‘i’ key to move the marble forward.